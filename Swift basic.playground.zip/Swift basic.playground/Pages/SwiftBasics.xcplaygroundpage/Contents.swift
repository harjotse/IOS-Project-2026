import Foundation
var greeting = "Hello, playground"
print(greeting)

// this is comment

 /*
  this is
  a multiline comment
  */
